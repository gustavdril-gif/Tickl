@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.satset.editor

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs

data class Seg(val s: Long, val e: Long) { val d get() = e - s }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Editor() } }
    }
}

fun clip(u: Uri, s: Seg) = MediaItem.Builder().setUri(u).setClippingConfiguration(
    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s.s).setEndPositionMs(s.e).build()
).build()

fun saveToGallery(ctx: Context, f: File) {
    val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "Satset_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SatsetEditor")
    }
    val out = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return
    ctx.contentResolver.openOutputStream(out)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    f.delete()
}

@Composable
fun Editor() {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var uri by remember { mutableStateOf<Uri?>(null) }
    var segs by remember { mutableStateOf(listOf<Seg>()) }
    var undo by remember { mutableStateOf(listOf<List<Seg>>()) }
    var redo by remember { mutableStateOf(listOf<List<Seg>>()) }
    var sel by remember { mutableStateOf(-1) }
    var land by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0L) }
    var cutT by remember { mutableStateOf<Long?>(null) }
    var status by remember { mutableStateOf("Pilih video untuk mulai") }
    val segsNow by rememberUpdatedState(segs)
    val cutNow by rememberUpdatedState(cutT)
    val tl = remember { floatArrayOf(0f, 1f) } // left, width di layar

    fun seekIn(list: List<Seg>, t: Long) {
        var a = 0L
        list.forEachIndexed { i, s ->
            if (t < a + s.d || i == list.lastIndex) { player.seekTo(i, (t - a).coerceIn(0, s.d)); return }
            a += s.d
        }
    }
    fun load(u: Uri, list: List<Seg>, t: Long) {
        player.setMediaItems(list.map { clip(u, it) }); player.prepare(); seekIn(list, t)
    }
    fun commit(n: List<Seg>) {
        undo = undo + listOf(segs); redo = emptyList(); segs = n; sel = -1
        uri?.let { load(it, n, pos) }
    }
    fun idxAt(list: List<Seg>, t: Long): Int {
        var a = 0L
        list.forEachIndexed { i, s -> if (t < a + s.d) return i; a += s.d }
        return list.lastIndex
    }
    fun doCut(t: Long) {
        var a = 0L
        segs.forEachIndexed { i, s ->
            if (t > a + 150 && t < a + s.d - 150) {
                val m = s.s + (t - a)
                commit(segs.toMutableList().apply { removeAt(i); add(i, Seg(m, s.e)); add(i, Seg(s.s, m)) })
                status = "Terpotong"; return
            }
            a += s.d
        }
        status = "Terlalu dekat tepi klip"
    }
    fun export() {
        val u = uri ?: return
        status = "Mengekspor..."
        val ratio = if (land) 16f / 9f else 9f / 16f
        val items = segs.map {
            EditedMediaItem.Builder(clip(u, it)).setEffects(
                Effects(listOf(), listOf(Presentation.createForAspectRatio(ratio, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)))
            ).build()
        }
        val comp = Composition.Builder(EditedMediaItemSequence(items)).build()
        val out = File(ctx.cacheDir, "out.mp4").also { it.delete() }
        Transformer.Builder(ctx).addListener(object : Transformer.Listener {
            override fun onCompleted(c: Composition, r: ExportResult) {
                Thread { saveToGallery(ctx, out) }.start(); status = "Tersimpan di Movies/SatsetEditor"
            }
            override fun onError(c: Composition, r: ExportResult, e: ExportException) { status = "Gagal: ${e.message}" }
        }).build().start(comp, out.absolutePath)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            val r = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            r.release()
            uri = u; segs = listOf(Seg(0, dur)); undo = emptyList(); redo = emptyList(); sel = -1; pos = 0
            load(u, segs, 0); status = "Tahan ✂ lalu geser di timeline"
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(80)
            if (cutNow == null && segsNow.isNotEmpty()) {
                var a = 0L
                for (i in 0 until player.currentMediaItemIndex) a += segsNow.getOrNull(i)?.d ?: 0
                pos = a + player.currentPosition.coerceAtLeast(0)
            }
        }
    }

    val total = segs.sumOf { it.d }
    Column(Modifier.fillMaxSize().background(Color(0xFF101010)).statusBarsPadding().navigationBarsPadding().padding(8.dp)) {
        var acc by remember { mutableStateOf(0f) }
        Box(
            Modifier.weight(1f).fillMaxWidth().pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = { if (abs(acc) > 150) land = !land; acc = 0f },
                    onDragCancel = { acc = 0f }
                ) { _, dx -> acc += dx }
            },
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { PlayerView(it).apply { this.player = player; useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM } },
                modifier = (if (land) Modifier.fillMaxWidth().aspectRatio(16f / 9f) else Modifier.fillMaxHeight().aspectRatio(9f / 16f)).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            )
            Text(if (land) "16:9  ‹ geser ›" else "9:16  ‹ geser ›", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.TopCenter))
        }

        // Tombol cut: tahan, geser di timeline, lepas
        var btn by remember { mutableStateOf(Offset.Zero) }
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(if (cutT != null) Color(0xFFFF5252) else Color(0xFF2E7D32))
                    .onGloballyPositioned { btn = it.positionInRoot() }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val d = awaitFirstDown()
                            if (segsNow.isEmpty()) return@awaitEachGesture
                            val tot = segsNow.sumOf { it.d }
                            fun upd(x: Float) {
                                val t = (((x - tl[0]) / tl[1]).coerceIn(0f, 1f) * tot).toLong()
                                cutT = t; seekIn(segsNow, t)
                            }
                            upd(btn.x + d.position.x)
                            while (true) {
                                val ch = awaitPointerEvent().changes.first()
                                if (!ch.pressed) break
                                upd(btn.x + ch.position.x); ch.consume()
                            }
                            cutT?.let { doCut(it) }; cutT = null
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Text("✂", fontSize = 24.sp, color = Color.White) }
        }

        // Timeline
        Canvas(
            Modifier.fillMaxWidth().height(56.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp)).background(Color(0xFF1E1E1E))
                .onGloballyPositioned { tl[0] = it.positionInRoot().x; tl[1] = it.size.width.toFloat().coerceAtLeast(1f) }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val tot = segsNow.sumOf { it.d }; if (tot == 0L) return@detectTapGestures
                        val t = (o.x / size.width * tot).toLong()
                        sel = idxAt(segsNow, t); seekIn(segsNow, t)
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { ch, _ ->
                        val tot = segsNow.sumOf { it.d }; if (tot == 0L) return@detectHorizontalDragGestures
                        seekIn(segsNow, (ch.position.x / size.width * tot).toLong().coerceIn(0, tot)); ch.consume()
                    }
                }
        ) {
            if (total > 0) {
                var x = 0f
                segs.forEachIndexed { i, s ->
                    val w = size.width * s.d / total
                    drawRect(if (i == sel) Color(0xFFFFC107) else Color(0xFF42A5F5), Offset(x, 4f), Size((w - 3f).coerceAtLeast(1f), size.height - 8f))
                    x += w
                }
                val px = size.width * (cutT ?: pos) / total
                drawRect(if (cutT != null) Color(0xFFFF5252) else Color.White, Offset(px - 1.5f, 0f), Size(3f, size.height))
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton({ picker.launch("video/*") }) { Text("Pilih") }
            TextButton({ if (player.isPlaying) player.pause() else player.play() }) { Text("▶/⏸") }
            TextButton({ if (undo.isNotEmpty()) { redo = redo + listOf(segs); segs = undo.last(); undo = undo.dropLast(1); sel = -1; uri?.let { load(it, segs, pos) } } }) { Text("↶") }
            TextButton({ if (redo.isNotEmpty()) { undo = undo + listOf(segs); segs = redo.last(); redo = redo.dropLast(1); sel = -1; uri?.let { load(it, segs, pos) } } }) { Text("↷") }
            TextButton({ if (sel in segs.indices && segs.size > 1) commit(segs.filterIndexed { i, _ -> i != sel }) else status = "Ketuk klip di timeline dulu" }) { Text("Hapus") }
            TextButton({ export() }) { Text("Ekspor") }
        }
        Text(status, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp))
    }
}
